# Ecommerce API Secure

API segura de e-commerce com autenticação JWT.

## Como rodar

```bash
npm install
npm run start
```

Configure o arquivo `.env` com suas variáveis.

---
Rotas:
- POST /api/auth/register
- POST /api/auth/login
- POST /api/products (autenticado)
- GET /api/products
- POST /api/orders (autenticado)
- GET /api/orders (autenticado)