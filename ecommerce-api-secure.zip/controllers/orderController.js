const Order = require('../models/Order');

exports.createOrder = async (req, res) => {
    try {
        const { products } = req.body;
        const order = await Order.create({ user: req.user.id, products });
        res.status(201).json(order);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
};

exports.getOrders = async (req, res) => {
    try {
        const orders = await Order.find({ user: req.user.id }).populate('products');
        res.json(orders);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
};